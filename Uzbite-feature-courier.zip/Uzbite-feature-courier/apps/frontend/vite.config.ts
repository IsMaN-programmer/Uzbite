import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({plugins:[react(),tailwindcss()],server:{host:'0.0.0.0',port:8080,strictPort:true,proxy:{'/api':{target:'http://127.0.0.1:8081',changeOrigin:true},'/socket.io':{target:'http://127.0.0.1:8081',ws:true,changeOrigin:true}}},build:{chunkSizeWarningLimit:650}});
